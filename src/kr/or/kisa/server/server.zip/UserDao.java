package kr.or.kisa.server;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
/**
 * @author �����
 *
 */

class MyObjectOutputStream extends ObjectOutputStream{

	protected MyObjectOutputStream(OutputStream out) throws IOException, SecurityException {
		super(out);
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void writeStreamHeader(){
		
	}
}

public class UserDao{
	
	/** �������� ���*/
	private static final String FILE_PATH = "user.dbf";
	
	FileInputStream fis; //����ų� ���� ����� ���� ���⼭ ...
	FileOutputStream fos;
	ObjectInputStream ooi;
	ObjectOutputStream oos;

	public UserDao(){
		
		
	}

	
	// ���ο� ���� ���� ���� 
	
	public void saveUser(User user) throws IOException{
		
		if(new File(FILE_PATH).exists()){
			fos = new FileOutputStream(FILE_PATH,true);
			oos = new MyObjectOutputStream(fos);
		}else{
			fos = new FileOutputStream(FILE_PATH,true);
			oos = new ObjectOutputStream(fos);
		}
	
		if (user instanceof Serializable) {
			oos.writeObject(user);
		}
		fos.flush();
		oos.flush();
		fos.close();
		oos.close();
		
		
	}
	

	
	// Ư�� ���� ���� ���
	public User getUser(String userId, int passwd) throws IOException, ClassNotFoundException{
		fis = new FileInputStream(FILE_PATH);
		ooi = new ObjectInputStream(fis);
		User user = null;

		
		User userCompare = null;
		while((user = (User)ooi.readObject()) != null){
			if(user.getNickName().equals(userId)){
				return user;
			}
		}
		return null;
	}
	
	// ��ü ���� ���� ���
	public void getUser() throws IOException, ClassNotFoundException{
		fis = new FileInputStream(FILE_PATH);
		ooi = new ObjectInputStream(fis);
		User user = null;
		User userCompare = null;
		
		while((user = (User) ooi.readObject()) != null){
			System.out.println("gg");
			if(user instanceof User){
				System.out.println(user);
			}else{
				return;
			}
		}
		while((user = (User) ooi.readObject()) != null){
			System.out.println(user.getNickName());
			
		}
		//fis.close();
		//ooi.close();
	}

	
	// ��Ʈ�� �ݱ�
	public void close(){

	}
	
	public static void main(String[] args) {
		UserDao userDao = new UserDao();
		try {
			userDao.saveUser(new User("111","����","����", 100, (byte)0, "������", "2323"));
			userDao.saveUser(new User("11214","����","����", 100, (byte)0, "������", "2323"));
			userDao.getUser();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}