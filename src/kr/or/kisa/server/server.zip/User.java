package kr.or.kisa.server;

import java.io.Serializable;

public class User  implements Serializable{

	private String nickName;
	private String userName;
	private String userId;
	private int passwd;
	private byte gender;
	private String birth;
	private String email;
	
	
	
	public User(){
		this(null, null, null, 0, (byte) 0, null, null);
	}
	public User(String nickName, String userName, String userId, int passwd,
			byte gender, String birth, String email) {
		super();
		this.nickName = nickName;
		this.userName = userName;
		this.userId = userId;
		this.passwd = passwd;
		this.gender = gender;
		this.birth = birth;
		this.email = email;
	}
	
	
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getPasswd() {
		return passwd;
	}
	public void setPasswd(int passwd) {
		this.passwd = passwd;
	}
	public byte getGender() {
		return gender;
	}
	public void setGender(byte gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	
}
